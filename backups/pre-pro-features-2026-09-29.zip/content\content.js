/**
 * OmniPrompt - Content script coordinator
 *
 * Creates the shadow-DOM host, boots the store and the four in-page modules,
 * and owns the one path that turns "user picked a prompt" into "text is in the
 * composer".
 *
 * Notable behaviour
 * -----------------
 * - Insertion preserves the draft. Prompts chosen from the slash menu replace
 *   only the typed `//token`; everything else inserts at the caret. The old
 *   coordinator called an insert that overwrote the whole field.
 * - Page context (selection, URL, title) is captured before any overlay opens,
 *   because opening one collapses the selection.
 * - The clipboard is never read unless the user has turned that on.
 * - Honours a per-site disable so the extension can be silenced on a site
 *   without uninstalling it.
 */

(function () {
  'use strict';

  if (window.__OMNIPROMPT_LOADED__) return;
  window.__OMNIPROMPT_LOADED__ = true;

  const HOST_ID = 'omniprompt-root';

  let shadowRoot = null;
  let hostElement = null;
  let settings = null;
  let disabledHere = false;

  /* =====================================================================
     Shadow host
     ===================================================================== */

  /**
   * All UI lives in a closed-off shadow root attached to documentElement, so
   * page CSS cannot reach in and our CSS cannot leak out.
   */
  function createHost() {
    let host = document.getElementById(HOST_ID);
    if (host && host.shadowRoot) {
      hostElement = host;
      return host.shadowRoot;
    }

    if (!host) {
      host = document.createElement('div');
      host.id = HOST_ID;
      // The host must not affect page layout.
      host.style.setProperty('all', 'initial', 'important');
      host.style.setProperty('position', 'fixed', 'important');
      host.style.setProperty('z-index', '2147483647', 'important');
      host.style.setProperty('top', '0', 'important');
      host.style.setProperty('left', '0', 'important');
      host.style.setProperty('width', '0', 'important');
      host.style.setProperty('height', '0', 'important');
      (document.body || document.documentElement).appendChild(host);
    }

    hostElement = host;
    const root = host.attachShadow({ mode: 'open' });

    const link = document.createElement('link');
    link.rel = 'stylesheet';
    link.href = chrome.runtime.getURL('content/content.css');
    root.appendChild(link);

    return root;
  }

  /* =====================================================================
     Page context
     ===================================================================== */

  /**
   * Snapshot what a template might want to auto-fill. Captured up front
   * because focusing an overlay clears the page selection.
   */
  function capturePageContext() {
    let selection = '';
    try {
      const sel = window.getSelection();
      if (sel) selection = String(sel.toString() || '').trim();
    } catch (e) {
      selection = '';
    }

    // Text highlighted inside the composer counts too.
    if (!selection && window.ChatbotAdapters) {
      const el = window.ChatbotAdapters.getInputElement();
      if (el && !el.isContentEditable && typeof el.selectionStart === 'number') {
        const start = el.selectionStart;
        const end = el.selectionEnd;
        if (end > start) selection = (el.value || '').slice(start, end).trim();
      }
    }

    return {
      selection,
      url: window.location.href,
      title: document.title
    };
  }

  /* =====================================================================
     The single insertion path
     ===================================================================== */

  /**
   * Write finished text into the page.
   *
   * @param {string} text
   * @param {object} options
   *   target        the element to write into
   *   caret         a snapshot from adapters.captureCaret, restored before
   *                 writing so a modal stealing focus cannot lose the position
   *   replaceLength when set, swap this many characters before the caret
   *                 (the slash menu's `//query`) instead of inserting
   *   submit        send the message afterwards
   *   mode          override the user's default insert mode
   */
  function writeToPage(text, options) {
    const opts = options || {};
    const adapters = window.ChatbotAdapters;
    if (!adapters) return { ok: false, reason: 'no-adapters' };

    const submit = Boolean(opts.submit);

    let result;
    if (opts.replaceLength) {
      result = adapters.replaceRange(opts.replaceLength, text, {
        target: opts.target,
        caret: opts.caret,
        submit
      });
    } else {
      result = adapters.insert(text, {
        target: opts.target,
        caret: opts.caret,
        mode: opts.mode || settings.insertMode,
        submit
      });
    }

    if (!result.ok) {
      // Falling back to the clipboard means the work is never lost, even on a
      // page with no editable field.
      copyText(text).then((copied) => {
        showToast(
          copied
            ? 'No text box found here. Copied to your clipboard instead.'
            : 'No text box found here, and the clipboard was blocked.',
          copied ? 'info' : 'warn'
        );
      });
    }

    return result;
  }

  /**
   * Run a prompt end to end: collect variables if needed, then write.
   */
  function runPrompt(prompt, options) {
    const opts = options || {};
    const context = capturePageContext();

    window.VariableModal.processPrompt(
      prompt,
      context,
      (renderedText, meta) => {
        const result = writeToPage(renderedText, {
          target: opts.target,
          caret: opts.caret,
          replaceLength: opts.replaceLength,
          submit: meta && typeof meta.submit === 'boolean' ? meta.submit : Boolean(opts.submit),
          mode: opts.mode
        });
        if (result.ok && window.OmniStore) window.OmniStore.recordUse(prompt.id);
      },
      {
        submit: opts.submit,
        allowClipboard: !!settings.clipboardAutofill,
        allowSubmit: true,
        // A prompt whose fields all resolved themselves goes straight in.
        skipWhenComplete: false,
        // Lets the user return to wherever they picked this prompt from
        // (the palette or the slash menu) instead of losing that state.
        onBack: opts.onBack
      }
    );
  }

  /**
   * Apply a quick modifier to the current draft or the page selection.
   */
  function runModifier(modifierId, options) {
    const opts = options || {};
    const modifiers = window.OmniModifiers;
    const adapters = window.ChatbotAdapters;
    if (!modifiers || !adapters) return;

    const modifier = modifiers.getById(modifierId);
    if (!modifier) return;

    const target =
      (opts.caret && opts.caret.el && adapters.isEditable(opts.caret.el) ? opts.caret.el : null) ||
      (opts.target && adapters.isEditable(opts.target) ? opts.target : adapters.getInputElement());

    // Priority: text the caller passed in, then the page selection, then
    // whatever is already in the composer.
    let source = typeof opts.text === 'string' ? opts.text.trim() : '';
    if (!source) source = capturePageContext().selection;
    if (!source && target) source = adapters.readValue(target).trim();

    if (!source) {
      showToast('Select some text, or type a draft first, then apply a modifier.', 'warn');
      return;
    }

    const transformed = modifier.transform(source);

    // Wrapping the user's own draft means replacing it; wrapping a page
    // selection means inserting alongside whatever is in the box.
    const draft = target ? adapters.readValue(target).trim() : '';
    const wrappedTheDraft = draft && draft === source;

    const result = adapters.insert(transformed, {
      target,
      caret: opts.caret,
      mode: wrappedTheDraft ? 'replace' : settings.insertMode,
      submit: false
    });

    if (result.ok) {
      showToast(modifier.icon + ' ' + modifier.title + ' applied.', 'ok');
    } else {
      copyText(transformed).then((copied) => {
        showToast(
          copied
            ? modifier.title + ' copied to your clipboard. Paste it anywhere.'
            : 'Could not insert or copy on this page.',
          copied ? 'info' : 'warn'
        );
      });
    }
  }

  /* =====================================================================
     Clipboard and toast
     ===================================================================== */

  function copyText(text) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      return navigator.clipboard.writeText(text).then(
        () => true,
        () => fallbackCopy(text)
      );
    }
    return Promise.resolve(fallbackCopy(text));
  }

  function fallbackCopy(text) {
    try {
      const area = document.createElement('textarea');
      area.value = text;
      area.setAttribute('readonly', 'readonly');
      area.style.position = 'fixed';
      area.style.top = '-1000px';
      document.body.appendChild(area);
      area.select();
      const ok = document.execCommand('copy');
      document.body.removeChild(area);
      return ok;
    } catch (e) {
      return false;
    }
  }

  let toastTimer = null;

  function showToast(message, kind) {
    if (!shadowRoot) return;

    let toast = shadowRoot.querySelector('.omni-floating-toast');
    if (!toast) {
      toast = document.createElement('div');
      toast.className = 'omni-floating-toast omni-textured';
      toast.setAttribute('role', 'status');
      shadowRoot.appendChild(toast);
    }

    const icon = kind === 'warn' ? '⚠️' : kind === 'ok' ? '✓' : '⚡';
    toast.innerHTML =
      '<span class="toast-icon">' + icon + '</span><span></span>';
    toast.querySelector('span:last-child').textContent = message;

    toast.classList.remove('omni-toast-hiding');
    toast.style.display = 'flex';

    if (toastTimer) window.clearTimeout(toastTimer);
    toastTimer = window.setTimeout(() => {
      toast.classList.add('omni-toast-hiding');
      window.setTimeout(() => {
        if (toast) toast.style.display = 'none';
      }, 250);
    }, 2800);
  }

  /* =====================================================================
     Wiring
     ===================================================================== */

  /**
   * Paint the injected overlays in the user's chosen skin. The attribute goes
   * on the host element rather than the page, so the shadow styles can react
   * without the page ever seeing it.
   */
  function applyTheme() {
    if (!hostElement || !window.OmniTheme) return;
    window.OmniTheme.apply(hostElement, settings ? settings.theme : 'system');
  }

  function applySettings() {
    settings = window.OmniStore.getSettings();
    disabledHere = window.OmniStore.isSiteDisabled(window.location.hostname);
    applyTheme();

    window.SlashTrigger.configure({
      triggerChar: settings.slashTriggerChar,
      enabled: settings.slashEnabled && !disabledHere,
      maxResults: settings.maxSlashResults
    });

    window.CommandPalette.configure({
      hotkey: settings.paletteHotkey,
      enabled: settings.enablePalette && !disabledHere
    });
  }

  function handleMessage(request, sender, sendResponse) {
    switch (request && request.action) {
      case 'ping':
        sendResponse({ ok: true, version: 2, site: window.ChatbotAdapters.siteLabel() });
        return false;

      case 'open_palette':
        if (disabledHere) {
          sendResponse({ ok: false, reason: 'site-disabled' });
          return false;
        }
        window.CommandPalette.toggle();
        sendResponse({ ok: true });
        return false;

      case 'insert_prompt': {
        // Text that the popup already rendered goes in as-is.
        if (typeof request.text === 'string') {
          const result = writeToPage(request.text, {
            submit: request.submit,
            mode: request.mode
          });
          if (result.ok && request.promptId && window.OmniStore) {
            window.OmniStore.recordUse(request.promptId);
          }
          sendResponse({ ok: result.ok, reason: result.reason });
          return false;
        }
        // Otherwise resolve it here so variables can use page context.
        const prompt = request.prompt || (window.OmniStore && window.OmniStore.getById(request.promptId));
        if (!prompt) {
          sendResponse({ ok: false, reason: 'unknown-prompt' });
          return false;
        }
        runPrompt(prompt, { submit: request.submit, mode: request.mode });
        sendResponse({ ok: true });
        return false;
      }

      case 'apply_modifier':
        runModifier(request.modifierId, { text: request.text });
        sendResponse({ ok: true });
        return false;

      case 'settings_changed':
        window.OmniStore.reload().then(() => {
          applySettings();
          sendResponse({ ok: true });
        });
        return true;

      default:
        sendResponse({ ok: false, reason: 'unknown-action' });
        return false;
    }
  }

  /**
   * Start up.
   *
   * Everything up to and including the message listener is registered
   * synchronously, before any await. Reading storage takes a tick, and a command
   * sent during that tick would otherwise find no listener and be reported as
   * "no content script". The modules start on the built-in defaults and are
   * reconfigured once the user's real settings arrive.
   */
  async function boot() {
    // The adapters start watching focus immediately, so the composer is known
    // even if the user opens the palette before typing anything.
    window.ChatbotAdapters.trackFocus();

    shadowRoot = createHost();

    // Defaults are available before storage has been read.
    settings = window.OmniStore.getSettings();
    disabledHere = false;
    applyTheme();

    // Follow the operating system while the choice is 'system'.
    if (window.OmniTheme) {
      window.OmniTheme.watchSystem(
        () => (settings ? settings.theme : 'system'),
        () => applyTheme()
      );
    }

    window.VariableModal.init(shadowRoot);

    window.SlashTrigger.init(
      shadowRoot,
      (prompt, ctx) => {
        runPrompt(prompt, {
          target: ctx && ctx.target,
          caret: ctx && ctx.caret,
          replaceLength: ctx && ctx.replaceLength,
          onBack: ctx && ctx.onBack
        });
      },
      {
        triggerChar: settings.slashTriggerChar,
        enabled: settings.slashEnabled && !disabledHere,
        maxResults: settings.maxSlashResults
      }
    );

    window.CommandPalette.init(
      shadowRoot,
      {
        onSelectPrompt: (prompt, ctx) => {
          runPrompt(prompt, {
            target: ctx && ctx.target,
            caret: ctx && ctx.caret,
            submit: ctx && ctx.submit,
            onBack: ctx && ctx.onBack
          });
        },
        onRunModifier: (id, ctx) => {
          runModifier(id, { target: ctx && ctx.target, caret: ctx && ctx.caret });
        }
      },
      {
        hotkey: settings.paletteHotkey,
        enabled: settings.enablePalette && !disabledHere
      }
    );

    // Registered before the first await, so a keyboard command that arrives
    // while storage is still loading is still answered.
    if (chrome.runtime && chrome.runtime.onMessage) {
      chrome.runtime.onMessage.addListener(handleMessage);
    }

    // A small surface for the offline sandbox page and for debugging.
    window.OmniPrompt = {
      version: 2,
      runPrompt,
      runModifier,
      openPalette: () => window.CommandPalette.open(),
      getContext: capturePageContext,
      isDisabledHere: () => disabledHere,
      isReady: () => window.OmniStore.isReady()
    };

    // Now pick up the user's stored prompts and settings.
    await window.OmniStore.init();
    window.OmniStore.watchStorage();
    window.OmniStore.onChange(() => applySettings());
    applySettings();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot, { once: true });
  } else {
    boot();
  }
})();
